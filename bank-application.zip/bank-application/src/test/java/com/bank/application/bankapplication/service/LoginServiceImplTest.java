package com.bank.application.bankapplication.service;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bank.application.bankapplication.entity.UserLogin;
import com.bank.application.bankapplication.repository.UserRepository;

@ExtendWith(SpringExtension.class)
public class LoginServiceImplTest {

	@Mock
	UserRepository userRepository;
	
	@Test
	public void testLoginCustomer() {
		UserLogin userLogin = new UserLogin();
		userLogin.setId(1);
		userLogin.setUserName("TEST");
		userLogin.setPassword("TEST");
		
		when(userRepository.findUserByUserNameAndPassword(userLogin.getUserName(), userLogin.getPassword())).thenReturn(Optional.of(userLogin));
		assertTrue(true);
	}

}
