package com.bank.application.bankapplication.resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bank.application.bankapplication.dto.AccountDTO;
import com.bank.application.bankapplication.dto.TransactionDetailsDTO;
import com.bank.application.bankapplication.service.TransactionService;
import com.bank.application.bankapplication.util.BanksConstants;

@ExtendWith(SpringExtension.class)
public class TransactionsControllerTest {

	@Mock
	TransactionService transactionService;

	@InjectMocks
	TransactionsController transactionsController;
	
	@Test
	public void testAddAmountToAccount() throws Exception {
		AccountDTO accountDetails= new AccountDTO();
		accountDetails.setAccountNumber(1);
		accountDetails.setAmount(1000f);
		doNothing().when(transactionService).addAmountToAccount(accountDetails);
		ResponseEntity<String> response = transactionsController.addAmountToAccount(accountDetails);
		assertEquals(BanksConstants.SUCCESS, response.getBody());
	}
	
	@Test
	public void testSendAmountToAccount() throws Exception {
		TransactionDetailsDTO transactionDetailsDTO= new TransactionDetailsDTO();
		transactionDetailsDTO.setToAccount(1);
		transactionDetailsDTO.setFromAccount(2);
		transactionDetailsDTO.setAmount(1000f);
		doNothing().when(transactionService).sendAmountToAccount(transactionDetailsDTO);
		ResponseEntity<String> response = transactionsController.sendAmountToAccount(transactionDetailsDTO);
		assertEquals(BanksConstants.SUCCESS, response.getBody());
	}
	
	@Test
	public void testWithdrawAmount() throws Exception {
		AccountDTO accountDetails= new AccountDTO();
		accountDetails.setAccountNumber(1);
		accountDetails.setAmount(1000f);
		doNothing().when(transactionService).withdrawAmount(accountDetails);
		ResponseEntity<String> response = transactionsController.withdrawAmount(accountDetails);
		assertEquals(BanksConstants.SUCCESS, response.getBody());
	}
}
