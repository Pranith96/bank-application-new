package com.bank.application.bankapplication.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bank.application.bankapplication.entity.Customer;
import com.bank.application.bankapplication.repository.BankAccountRepository;
import com.bank.application.bankapplication.repository.CustomerRepository;
import com.bank.application.bankapplication.util.BanksConstants;

@ExtendWith(SpringExtension.class)
public class RegistrationServiceImplTest {

	@Mock
	CustomerRepository customerRepository;
	
	@Mock
	BankAccountRepository bankAccountRepository;

	@InjectMocks
	RegistrationServiceImpl registrationServiceImpl;

	@Test
	public void testCreateCustomer() throws Exception {

		Customer customer = new Customer();
		customer.setCifNumber(12345678);
		customer.setFullName("TEST");
		customer.setMobileNumber("8765432190");

		when(customerRepository.save(customer)).thenReturn(customer);
		String response = registrationServiceImpl.createCustomer(customer);
		assertEquals(BanksConstants.CUSTOMER_CREATED_SUCCESSFULLY, response);
	}
	
	@Test
	public void testDeleteCustomer() throws Exception {

		doNothing().when(customerRepository).deleteById(1);
		doNothing().when(bankAccountRepository).deleteById(1);
		String response = registrationServiceImpl.deleteCustomer(1);
		assertEquals(BanksConstants.CUSTOMER_DELETED_SUCCESSFULLY, response);
	}

}
