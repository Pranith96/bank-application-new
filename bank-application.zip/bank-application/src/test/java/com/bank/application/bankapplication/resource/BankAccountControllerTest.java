package com.bank.application.bankapplication.resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bank.application.bankapplication.dto.AccountCreationRequest;
import com.bank.application.bankapplication.entity.AccountType;
import com.bank.application.bankapplication.service.BankAccountService;
import com.bank.application.bankapplication.util.BanksConstants;

@ExtendWith(SpringExtension.class)
public class BankAccountControllerTest {

	@Mock
	BankAccountService bankAccountService;

	@InjectMocks
	BankAccountController bankAccountController;

	@Test
	public void testCreateBankAccount() throws Exception {
		AccountCreationRequest accountCreationRequest = new AccountCreationRequest();
		accountCreationRequest.setAmount(1000f);
		accountCreationRequest.setCifNumber(1);
		accountCreationRequest.setAccountType(AccountType.CURRENT);
		when(bankAccountService.createBankAccount(accountCreationRequest))
				.thenReturn(BanksConstants.BANK_ACCOUNT_CREATED_SUCCESSFULLY);
		ResponseEntity<String> response = bankAccountController.createBankAccount(accountCreationRequest);
		assertEquals(BanksConstants.BANK_ACCOUNT_CREATED_SUCCESSFULLY, response.getBody());
	}

	@Test
	public void testGetBalance() throws Exception {
		when(bankAccountService.getBalance(1)).thenReturn(1000f);
		ResponseEntity<String> response = bankAccountController.getBalance(1);
		String balanceInfo = "Account Balance Info: ".concat(String.valueOf(1000f));
		assertEquals(balanceInfo, response.getBody());
	}

	@Test
	public void testAccountDelete() throws Exception {
		when(bankAccountService.accountDelete(1)).thenReturn(BanksConstants.BANK_ACCOUNT_REMOVED_SUCCESSFULLY);
		ResponseEntity<String> response = bankAccountController.accountDelete(1);
		assertEquals(BanksConstants.BANK_ACCOUNT_REMOVED_SUCCESSFULLY, response.getBody());
	}

	@Test
	public void testRemoveAccount() throws Exception {
		when(bankAccountService.removeAccount(1)).thenReturn(BanksConstants.BANK_ACCOUNT_REMOVED_SUCCESSFULLY);
		ResponseEntity<String> response = bankAccountController.removeAccount(1);
		assertEquals(BanksConstants.BANK_ACCOUNT_REMOVED_SUCCESSFULLY, response.getBody());
	}

}
