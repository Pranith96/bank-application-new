package com.bank.application.bankapplication.resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bank.application.bankapplication.dto.LoginDto;
import com.bank.application.bankapplication.service.LoginService;
import com.bank.application.bankapplication.util.BanksConstants;

@ExtendWith(SpringExtension.class)
public class LoginControllerTest {

	@Mock
	LoginService loginService;

	@InjectMocks
	LoginController loginController;

	@Test
	public void testCreateCustomer() throws Exception {
		LoginDto login = new LoginDto();
		login.setUserName("TEST");
		login.setPassword("TEST");
		when(loginService.loginCustomer(login.getUserName(), login.getPassword())).thenReturn(BanksConstants.LOGIN_SUCCESFULL);
		ResponseEntity<String> response = loginController.loginCustomer(login);
		assertEquals(BanksConstants.LOGIN_SUCCESFULL, response.getBody());
	}
}
