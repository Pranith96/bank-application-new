package com.bank.application.bankapplication.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bank.application.bankapplication.dto.AccountCreationRequest;
import com.bank.application.bankapplication.entity.AccountType;
import com.bank.application.bankapplication.entity.Accounts;
import com.bank.application.bankapplication.repository.BankAccountRepository;
import com.bank.application.bankapplication.repository.TransactionRepository;
import com.bank.application.bankapplication.util.BanksConstants;

@ExtendWith(SpringExtension.class)
public class BankAccountServiceImplTest {

	@Mock
	BankAccountRepository bankAccountRepository;

	@Mock
	TransactionRepository transactionRepository;

	@InjectMocks
	BankAccountServiceImpl bankAccountServiceImpl;

	@Test
	public void testCreateBankAccount() throws Exception {
		AccountCreationRequest accountRequest = new AccountCreationRequest();
		accountRequest.setAccountType(AccountType.INDIVIDUAL);
		accountRequest.setAmount(10000f);
		accountRequest.setCifNumber(1);
		Accounts account = new Accounts();
		account.setAccountType(accountRequest.getAccountType());
		account.setAmount(accountRequest.getAmount());
		account.setCifNumber(accountRequest.getCifNumber());
		account.setAccountStatus(BanksConstants.ACTIVE);
		when(bankAccountRepository.save(account)).thenReturn(account);
		String response = bankAccountServiceImpl.createBankAccount(accountRequest);
		assertEquals(BanksConstants.BANK_ACCOUNT_CREATED_SUCCESSFULLY, response);
	}

	@Test
	public void testgetAllAccounts() throws Exception {
		List<Accounts> accountsList = new ArrayList<>();
		Accounts account = new Accounts();
		account.setAccountType(AccountType.CURRENT);
		account.setAmount(1000f);
		account.setCifNumber(1);
		account.setAccountStatus(BanksConstants.ACTIVE);
		accountsList.add(account);
		when(bankAccountRepository.findAccountsByCifNumber(1)).thenReturn(accountsList);
		List<Accounts> accountsListResponse = bankAccountServiceImpl.getAllAccounts(1);
		assertEquals(1, accountsListResponse.size());
	}

	@Test
	public void testGetBalance() throws Exception {
		Accounts account = new Accounts();
		account.setAccountType(AccountType.CURRENT);
		account.setAmount(1000f);
		account.setCifNumber(1);
		account.setAccountStatus(BanksConstants.ACTIVE);
		when(bankAccountRepository.findById(1)).thenReturn(Optional.of(account));
		Float amount = bankAccountServiceImpl.getBalance(1);
		assertEquals(1000f, amount);
	}

	@Test
	public void testAccountDelete() throws Exception {
		doNothing().when(bankAccountRepository).deleteById(1);
		String response = bankAccountServiceImpl.accountDelete(1);
		assertEquals(BanksConstants.BANK_ACCOUNT_REMOVED_SUCCESSFULLY, response);
	}
}
