package com.bank.application.bankapplication.resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bank.application.bankapplication.entity.Customer;
import com.bank.application.bankapplication.service.RegistrationService;
import com.bank.application.bankapplication.util.BanksConstants;

@ExtendWith(SpringExtension.class)
public class RegistrationControllerTest {

	@Mock
	RegistrationService registrationService;

	@InjectMocks
	RegistrationController registrationController;

	@Test
	public void testCreateCustomer() throws Exception {
		Customer customer = new Customer();
		customer.setCifNumber(1);
		customer.setFullName("TEST");
		when(registrationService.createCustomer(customer)).thenReturn(BanksConstants.CUSTOMER_CREATED_SUCCESSFULLY);
		ResponseEntity<String> response = registrationController.createCustomer(customer);
		assertEquals(BanksConstants.CUSTOMER_CREATED_SUCCESSFULLY, response.getBody());
	}
	
	@Test
	public void testDeleteCustomer() throws Exception {
		when(registrationService.deleteCustomer(1)).thenReturn(BanksConstants.CUSTOMER_DELETED_SUCCESSFULLY);
		ResponseEntity<String> response = registrationController.deleteCustomer(1);
		assertEquals(BanksConstants.CUSTOMER_DELETED_SUCCESSFULLY, response.getBody());
	}
	
	@Test
	public void testRemoveCustomer() throws Exception {
		when(registrationService.removeCustomer(1)).thenReturn(BanksConstants.CUSTOMER_REMOVED_SUCCESSFULLY);
		ResponseEntity<String> response = registrationController.removeCustomer(1);
		assertEquals(BanksConstants.CUSTOMER_REMOVED_SUCCESSFULLY, response.getBody());
	}
}
