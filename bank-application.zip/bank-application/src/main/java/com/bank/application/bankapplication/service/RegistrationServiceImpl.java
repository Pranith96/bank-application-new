package com.bank.application.bankapplication.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.application.bankapplication.entity.Customer;
import com.bank.application.bankapplication.repository.BankAccountRepository;
import com.bank.application.bankapplication.repository.CustomerRepository;
import com.bank.application.bankapplication.util.BanksConstants;

@Service
@Transactional
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	BankAccountRepository bankAccountRepository;

	@Override
	public String createCustomer(Customer customer) throws Exception {
		customer.setCustomerStatus(BanksConstants.ACTIVE);
		Customer customerDetails = customerRepository.save(customer);

		if (customerDetails == null) {
			throw new Exception(BanksConstants.DETAILS_NOT_SAVED);
		}

		return BanksConstants.CUSTOMER_CREATED_SUCCESSFULLY;
	}

	@Override
	public String deleteCustomer(int cifNumber) throws Exception {

		customerRepository.deleteById(cifNumber);
		bankAccountRepository.deleteAllAccountsByCifNumber(cifNumber);

		return BanksConstants.CUSTOMER_DELETED_SUCCESSFULLY;
	}

	@Override
	public String removeCustomer(int cifNumber) throws Exception {

		float amount = 0;

		Optional<Customer> customerResponse = customerRepository.findById(cifNumber);

		if (!customerResponse.isPresent()) {
			throw new Exception(BanksConstants.DETAILS_NOT_FOUND);
		}

		customerResponse.get().setCustomerStatus(BanksConstants.INACTIVE);

		customerRepository.save(customerResponse.get());

		bankAccountRepository.updateAllAccountsStatusToInActive(BanksConstants.INACTIVE, cifNumber, amount);

		return BanksConstants.CUSTOMER_REMOVED_SUCCESSFULLY;
	}
}
