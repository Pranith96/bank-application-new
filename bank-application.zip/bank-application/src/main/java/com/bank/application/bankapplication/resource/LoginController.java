package com.bank.application.bankapplication.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.application.bankapplication.dto.LoginDto;
import com.bank.application.bankapplication.service.LoginService;
import com.bank.application.bankapplication.util.BanksConstants;

@RestController
@RequestMapping("/bank")
public class LoginController {

	@Autowired
	LoginService loginService;

	@PostMapping(value = "/login")
	public ResponseEntity<String> loginCustomer(@RequestBody LoginDto login) throws Exception {

		String userName = login.getUserName();
		String password = login.getPassword();

		String response = loginService.loginCustomer(userName, password);

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
}
