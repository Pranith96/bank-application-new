package com.bank.application.bankapplication.dto;

import lombok.Data;

@Data
public class AccountDTO {
	
	private int accountNumber;
	private float amount;

}
