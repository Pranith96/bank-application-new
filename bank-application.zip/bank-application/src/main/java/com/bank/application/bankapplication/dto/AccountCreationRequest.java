package com.bank.application.bankapplication.dto;

import com.bank.application.bankapplication.entity.AccountType;

import lombok.Data;

@Data
public class AccountCreationRequest {

	private float amount;
	private AccountType accountType;
	private int cifNumber;

}
