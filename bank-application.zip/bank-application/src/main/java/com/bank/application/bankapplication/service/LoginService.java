package com.bank.application.bankapplication.service;

public interface LoginService {

	String loginCustomer(String userName, String password) throws Exception;

}
