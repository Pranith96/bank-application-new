package com.bank.application.bankapplication.dto;

import lombok.Data;

@Data
public class LoginDto {

	private String userName;
	private String password;
}
