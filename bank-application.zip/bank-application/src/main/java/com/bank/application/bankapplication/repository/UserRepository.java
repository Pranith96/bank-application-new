package com.bank.application.bankapplication.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bank.application.bankapplication.entity.UserLogin;

@Repository
public interface UserRepository extends JpaRepository<UserLogin, Integer> {

	Optional<UserLogin> findUserByUserNameAndPassword(String userName, String password);

	UserLogin findByUserName(String name);

}
