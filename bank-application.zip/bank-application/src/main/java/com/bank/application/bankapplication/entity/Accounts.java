package com.bank.application.bankapplication.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.sun.istack.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@Data
@ApiModel(description = "Details About the Bank Accounts")
public class Accounts implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "seq", initialValue = 5555)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
    @ApiModelProperty(notes = "The Unique Account Number")
    private int accountNumber;

    @Enumerated(EnumType.STRING)
    @NotNull
    @Column(name = "account_type")
    @ApiModelProperty(notes = "It is the  Account Type")
    private AccountType accountType;
    
    @ApiModelProperty(notes = "It is account balance")
    private float amount;

    @ApiModelProperty(notes = "It is Customer Number property")
	private int cifNumber;
    
    @ApiModelProperty(notes = "It is Account status property")
    private String accountStatus;

    @CreationTimestamp
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

}
