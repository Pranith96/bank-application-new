package com.bank.application.bankapplication.entity;

public enum AccountType {

	INDIVIDUAL("INDIVIDUAL"), CURRENT("CURRENT"), JOINT("JOINT");

	private String code;

	AccountType(String code) {
		this.code = code;
	}

	public String code() {
		return this.code;
	}

}